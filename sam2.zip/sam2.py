a=int(input("\n Enter Hours"))
b=float(input("\n Enter Rate"))
c=a*b
print("\n Gross Pay",round(c))
