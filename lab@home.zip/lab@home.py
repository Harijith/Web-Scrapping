print(5)
x=5
x+1
print(x)
