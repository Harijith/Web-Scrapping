print("Good Morning)
